USE [testFarmeramaDW]
GO
/* Create stage, data warehouse and etl schemas */
CREATE SCHEMA [stage]
GO

CREATE SCHEMA [dwh]
GO

CREATE SCHEMA [etl]
GO
